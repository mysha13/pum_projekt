﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace boxitem
{
    class CurrentInfo
    {
        private int UserId { set; get; }
        private int BoxId { set; get; }
        private int ItemId { set; get; }

    }
}
